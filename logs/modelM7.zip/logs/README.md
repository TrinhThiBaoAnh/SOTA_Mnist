Model logs directory
